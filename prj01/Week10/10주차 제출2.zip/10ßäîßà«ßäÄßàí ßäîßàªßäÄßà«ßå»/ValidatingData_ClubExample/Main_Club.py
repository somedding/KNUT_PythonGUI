
from Club import *

oProgrammingClub = Club('Programming', 7)

oProgrammingClub.addMember('Joe Schmoe')
oProgrammingClub.addMember('Cindy Lou Hoo')
oProgrammingClub.addMember('Dino Richmond')
oProgrammingClub.addMember('Susie Sweetness')
oProgrammingClub.addMember('Fred Farkle')
oProgrammingClub.addMember('Kim Seung Jin')
oProgrammingClub.addMember('Hong')

oProgrammingClub.report()

oProgrammingClub.addMember('Iwanna Join')
oProgrammingClub.addMember('Dang')
